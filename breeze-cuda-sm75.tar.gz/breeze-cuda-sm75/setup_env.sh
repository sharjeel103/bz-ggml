#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
mkdir -p /kaggle/working/bz-ggml/build/third_party/ggml/src/ggml-cuda
cp -P $DIR/lib/libbreeze.so /kaggle/working/bz-ggml/build/
cp -P $DIR/lib/libggml*.so* /kaggle/working/bz-ggml/build/third_party/ggml/src/
cp -P $DIR/lib/libggml-cuda*.so* /kaggle/working/bz-ggml/build/third_party/ggml/src/ggml-cuda/
ln -sf /usr/local/nvidia/lib64/libcuda.so /usr/lib/x86_64-linux-gnu/libcuda.so
ln -sf $DIR/lib/*.so* /usr/lib/x86_64-linux-gnu/
ldconfig
echo "✅ breeze-cuda-sm75 environment ready!"
