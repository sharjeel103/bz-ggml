#!/usr/bin/env bash
DIR=""
export LD_LIBRARY_PATH="/lib:"
export PATH="/bin:/home/sharjeel/.gemini/antigravity-cli/bin:/home/sharjeel/.opencode/bin:/home/sharjeel/.bun/bin:/home/sharjeel/.local/share/pnpm/bin:/home/sharjeel/.local/bin:/home/sharjeel/bin:/home/sharjeel/.global-venv/bin:/home/sharjeel/.nvm/versions/node/v24.11.0/bin:/home/sharjeel/.local/bin:/home/sharjeel/.cargo/bin:/home/sharjeel/.local/bin:/home/sharjeel/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/snap/bin:/usr/local/go/bin:/home/sharjeel/Android/Sdk/emulator:/home/sharjeel/Android/Sdk/platform-tools:/home/sharjeel/Android/Sdk/cmdline-tools/latest/bin:/usr/lib/jvm/java-17-openjdk-amd64/bin:/home/sharjeel/go/bin"
